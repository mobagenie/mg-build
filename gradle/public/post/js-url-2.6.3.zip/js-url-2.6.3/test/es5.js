var url = require('../dist/es5-url-tld.min.js');

console.log(url('hostname', 'https://websanova.com'))