---
draft: true
date: {{ .Date }}
title: "{{ replace .TranslationBaseName "-" " " | title }}"
slug: {{ .BaseFileName }}

tags:
    - Python

categories:
    - Pemrograman


image: https://lorempixel.com/720/380
thumbnail: https://lorempixel.com/320/160
---