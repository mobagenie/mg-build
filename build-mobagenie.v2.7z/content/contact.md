---
title: "Contact"
date: 2019-05-12T20:22:51+07:00
draft: false
type: "page"
layout: "contact"
slug : "/contact"
breadcrumb: [Contact]
cover_image : 
---

If you require any more information about partnership, jobs, endorsement, advertising, or have any questions,  and more about our site's, please feel free to contact us.
<br /><br />
E-mail : <a href="mailto:milengame4270@gmail.com">milengame4270@gmail.com</a>
<br />