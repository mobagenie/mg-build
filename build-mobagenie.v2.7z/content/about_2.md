---
title: "About"
date: 2019-05-08T02:09:52+07:00
type: "page"
layout: "about"
slug : "/about"
breadcrumb: [About]
cover_image : 
---

<br><br>
MobaGenie adalah situs Media Informasi yang berfokus pada seputar Dunia Game MOBA MOBILE dan PC. dari mulai Mobile Legends, DOTA2, Arena of Valor, League of Legends, Wild Rift, Lokapala, Vainglory, dan Game MOBA lain.
<br><br/>
Informasi yang disajikan di situs ini meliputi Update Berita, Guide, Fakta Unik, Info Pro Player, Esports, Leaderboard, Redeem Code Tools MOBA dan lain sebagainya. 
		</br><br>