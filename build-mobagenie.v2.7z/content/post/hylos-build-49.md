---
title: Build hylos Mobile Legends by ϱöʞ||нɒи 
post_highlight: "Player: ϱöʞ||нɒи  WR: 80.1% Match: 395  Tier: A+ Tier Lane: Roam"
slug: build-hylos-mlbb-by
filename: "hylos-build-49.html"
categories: 
- Build 
- Mobile Legends
tags: 
- ""
- "hylos"
playername: "ϱöʞ||нɒи "
cleanplayername: ""
heroname: "hylos"
images: ../p/images/buildk/hylos.png
draft: false
type: post
---

{{< HeroInfo HeroName="Phoveous" View="37655" Role="1" BP="32000" DM="599" Ticket="0" Player="ϱöʞ||нɒи " CleanPlayerName="" WR="80.1%" League="x 850" Match="395 " HeroTier="3" TierLabel="A+ Tier" LaneImg="2" LaneLabel="Roam" >}} {{< /HeroInfo >}}
 
{{< OffensiveBuild build1="WarriorBoots"  build2="ClockofDestiny" build3="AthenasShield" build4="QueensWings" build5="Immortality" build6="DominanceIce" >}} {{</ OffensiveBuild >}}  

{{< BalancedBuild build1="WarriorBoots"  build2="AntiqueCuirass" build3="CursedHelmet" build4="TwilightArmor" build5="AthenasShield" build6="Immortality" >}} {{</ BalancedBuild >}}  

{{< RecommendedSpells SpellName1="Revitalize" SpellImg1="5" SpellName2="Aegis" SpellImg2="6" >}} {{</ RecommendedSpells >}}   

{{< RecommendedEmblems EmblemName1="Support" EmblemImg1="8" EmblemName2="Tank" EmblemImg2="3" >}} {{</ RecommendedEmblems >}}   

{{< ChampionSkills SkillDesc1="<b>Thickened Blood<br>For each 1 Max Mana he gains from Equipment items and Emblems, Hylos gains an extra 1.5 Max HP. When Mana is not enough, HP will be used to cast skills instead." SkillImg1="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/0a22fd3d66f2f408958b515113312e0d.png"  SkillDesc2="<b>Law and Order<br>Hylos stores nature's energy to lock down the target and deals 300<font color='#27C0C7'>( +80% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> and stuns the target for 1s." SkillImg2="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/21d45b4c6117aab4f4b75185bacb6de8.png"  SkillDesc3="<b>Ring of Punishment<br>Hylos releases the Ring of Punishment, dealing 120<font color='#27C0C7'>( +20% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> every second to surrounding enemies, slowing them by 6%, and reducing their Attack Speed by 5%. Stacks up to 10 times. Each stack lasts for 2.5s and increases the damage of <font color='#404495'>(Ring of Punishment)</font> by 5%. Ring of Punishment consumes 30 Mana every second when it is active. <font color='#404495'>(Use Again)</font>: Hylos cancels the <font color='#404495'>(Ring of Punishment)</font>." SkillImg3="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/15cb2a345e382497440d5ffe2fc01af5.png"  SkillDesc4="<b>Glorious Pathway<br>Hylos creates a pathway for 6s. He recovers 3% of Max HP and is immune to Slowing Effect while on the pathway. Allies moving towards the pathway will have their Movement Speed increased by 60%, enemies moving away from the pathway will have their Movement Speed reduced by 70%." SkillImg4="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/f822115ff2a7ff7dc87652ccae5cfbef.png"  >}} {{</ ChampionSkills >}}
	

{{< ChampionAttributes >}}

	{{< ChampionAttributes/Config img="mspeed.png" Attrib="Movement SPD:" AttribVal="260"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pattack" Attrib="Physical Attack" AttribVal="105"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mpower" Attrib="Magic Power" AttribVal="0"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pdefense" Attrib="Physical Defense" AttribVal="17"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mdefense" Attrib="Magical Defense" AttribVal="10"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hp" Attrib="HP" AttribVal="3109"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mana" Attrib="Mana:" AttribVal="430"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="aspeed" Attrib="Attack Speed:" AttribVal="0.826"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hregen" Attrib="Hp Regen" AttribVal="18.4"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mregen" Attrib="Mana Regen:" AttribVal="2.4"  >}} 
	{{</ ChampionAttributes/Config >}}
	
	
{{</ ChampionAttributes >}}


{{< FightingAbility >}}

	{{< FightingAbility/Config  Percentage="40"Label="Offense" >}} 
	{{</ FightingAbility/Config >}}		
	{{< FightingAbility/Config  Percentage="93"Label="Durability" >}} 
	{{</ FightingAbility/Config >}}
	{{< FightingAbility/Config  Percentage="65"Label="Ability Effects" >}} 
	{{</ FightingAbility/Config >}}
	
{{< FightingAbility >}}

{{< GetStory Story=" Amidst the misty mountains within the northern reaches of the Land of Dawn, reside an ancient and mysterious race of Centaurs. These centaurs guard a fountain that rests on the highest mountain peak. This fountain is said to give the gift of life. Dark forces have relentlessly tried to gain the power found within the waters of this fountain, but only to be time and time again be thwarted by the centaurs. However, as time went on, the centaurs tired and attrition soon took hold. It was not until he arrived. Where throw his mastery of nature\'s wrath he was able to punish all the invaders of the fountain. Hylos had become a legendary figure within the annals of the Land of Dawn. " >}}  {{</ GetStory >}}

{{< StrongAgainst >}}

	{{< StrongAgainst/Config href="fanny-build-17" HeroName="fanny">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="natalia-build-24" HeroName="natalia">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="odette-build-46" HeroName="odette">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="eudora-build-15" HeroName="eudora">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="sun-build-27" HeroName="sun">}} {{</ StrongAgainst/Config >}}
	
{{</ StrongAgainst >}}

{{< WeakAgainst >}}

	{{< WeakAgainst/Config href="hayabusa-build-21" HeroName="hayabusa">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="lancelot-build-47" HeroName="lancelot">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="kagura-build-25" HeroName="kagura">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="harley-build-42" HeroName="harley">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="helcurt-build-51" HeroName="helcurt">}} {{</ WeakAgainst/Config >}}
	
{{</ WeakAgainst >}}
