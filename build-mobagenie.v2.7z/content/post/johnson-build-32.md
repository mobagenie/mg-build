---
title: Build johnson Mobile Legends by ʛʌɲɲɪƈυƨ
post_highlight: "Player: ʛʌɲɲɪƈυƨ WR: 72.2% Match: 1183  Tier: S Tier Lane: Roam"
slug: build-johnson-mlbb-by
filename: "johnson-build-32.html"
categories: 
- Build 
- Mobile Legends
tags: 
- ""
- "johnson"
playername: "ʛʌɲɲɪƈυƨ"
cleanplayername: ""
heroname: "johnson"
images: ../p/images/buildk/johnson.png
draft: false
type: post
---

{{< HeroInfo HeroName="Phoveous" View="108210" Role="1" BP="32000" DM="599" Ticket="0" Player="ʛʌɲɲɪƈυƨ" CleanPlayerName="" WR="72.2%" League="x 521" Match="1183 " HeroTier="2" TierLabel="S Tier" LaneImg="2" LaneLabel="Roam" >}} {{< /HeroInfo >}}
 
{{< OffensiveBuild build1="WarriorBoots"  build2="BladeArmor" build3="AthenasShield" build4="BruteForceBreastplate" build5="Immortality" build6="QueensWings" >}} {{</ OffensiveBuild >}}  

{{< BalancedBuild build1="WarriorBoots"  build2="BladeArmor" build3="CursedHelmet" build4="AthenasShield" build5="TwilightArmor" build6="Immortality" >}} {{</ BalancedBuild >}}  

{{< RecommendedSpells SpellName1="Petrify" SpellImg1="7" SpellName2="Flicker" SpellImg2="10" >}} {{</ RecommendedSpells >}}   

{{< RecommendedEmblems EmblemName1="Tank" EmblemImg1="3" EmblemName2="Tank" EmblemImg2="3" >}} {{</ RecommendedEmblems >}}   

{{< ChampionSkills SkillDesc1="<b>Electro-airbag<br>When Johnson's HP is lower than 30%, he gains 300<font color='#47BE34'>( +700% Total Physical DEF)</font> shield for 10s. This effect has a CD of 100s." SkillImg1="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/d5efd721825bdfaf1f1299cd7be2f61f.png"  SkillDesc2="<b>Deadly Pincers<br>Johnson throws a spanner in the designated direction that deals 150<font color='#47BE34'>( +200% Total Physical DEF)</font> <font color='#3B69FF'>(Magic Damage)</font> to enemies on its path. Enemies in the area that the spanner lands will be stunned by 0.8s." SkillImg2="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/8c9bfe859e927799f3bdf13104685619.png"  SkillDesc3="<b>Electromag Rays<br>Johnson raises his shield, continuously dealing 100<font color='#27C0C7'>( +40% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> forwards in a fan-shape area and slowing enemies by 20%. Johnson can cast Basic Attack and skills normally while the shield is raised up." SkillImg3="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/6038b6b112bc3b71c7557cb8570f5b3f.png"  SkillDesc4="<b>Rapid Touchdown<br><font color='#404495'>(Passive)</font>: Permanently increases Physical Defense by 10%. Johnson jumps up and transforms into a car, accelerating over time. Only 1 teammate can get in the car when it's at low speed, and then they will rush forward along with Johnson. The car will explode upon hitting an enemy hero, stunning the target and nearby enemies for 0.5-1s, and dealing 300<font color='#27C0C7'>( +160% Total Magic Power)</font>-525<font color='#27C0C7'>( +280% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> according to the car's speed. After the explosion, the ground will be electrified, slowing enemies and dealing 80<font color='#27C0C7'>( +20% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> to those who are in the area. When the car is going slowly, tap the skill <font color='#404495'>(Throttle)</font> again to move faster. Tap the skill <font color='#404495'>(Brake)</font> to stop immediately. Hold the <font color='#404495'>(Nitrous)</font> skill to increase speed, for up to 5s. When he starts driving, Johnson's location is revealed and made visible for 3s." SkillImg4="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/595fb960f43aa952ca7d86089a3779cb.png"  >}} {{</ ChampionSkills >}}
	

{{< ChampionAttributes >}}

	{{< ChampionAttributes/Config img="mspeed.png" Attrib="Movement SPD:" AttribVal="255"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pattack" Attrib="Physical Attack" AttribVal="120"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mpower" Attrib="Magic Power" AttribVal="0"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pdefense" Attrib="Physical Defense" AttribVal="27"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mdefense" Attrib="Magical Defense" AttribVal="10"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hp" Attrib="HP" AttribVal="2809"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mana" Attrib="Mana:" AttribVal="0"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="aspeed" Attrib="Attack Speed:" AttribVal="0.826"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hregen" Attrib="Hp Regen" AttribVal="8.4"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mregen" Attrib="Mana Regen:" AttribVal="2.4"  >}} 
	{{</ ChampionAttributes/Config >}}
	
	
{{</ ChampionAttributes >}}


{{< FightingAbility >}}

	{{< FightingAbility/Config  Percentage="40"Label="Offense" >}} 
	{{</ FightingAbility/Config >}}		
	{{< FightingAbility/Config  Percentage="93"Label="Durability" >}} 
	{{</ FightingAbility/Config >}}
	{{< FightingAbility/Config  Percentage="61"Label="Ability Effects" >}} 
	{{</ FightingAbility/Config >}}
	
{{< FightingAbility >}}

{{< GetStory Story=" Johnson, with a hardy constitution as a rock, when he ran through the dome stadium like a heavy truck, the cheers of girls Burst out loud. He led the team to lift the champion\'s trophies and achieved his peak of his life as a super quarterback with millions fans around. However, fortune is always fickle. A little girl rushed to the road in a sudden while Johnson was driving his sport car. To avoid hitting on the little girl, his car crashed severely. Massive hemorrhage was going to take away his life soon in a minute. At that moment, a miracle occurred, that the wreckage of the sport car started to blend into Johnson\'s body by a mystery force. Consequently, he not only just survived from the crash, also became a magical new human who can transform to a sport car. " >}}  {{</ GetStory >}}

{{< StrongAgainst >}}

	{{< StrongAgainst/Config href="miya-build-1" HeroName="miya">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="saber-build-3" HeroName="saber">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="alucard-build-7" HeroName="alucard">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="fanny-build-17" HeroName="fanny">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="natalia-build-24" HeroName="natalia">}} {{</ StrongAgainst/Config >}}
	
{{</ StrongAgainst >}}

{{< WeakAgainst >}}

	{{< WeakAgainst/Config href="eudora-build-15" HeroName="eudora">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="kagura-build-25" HeroName="kagura">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="gord-build-23" HeroName="gord">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="karina-build-8" HeroName="karina">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="sun-build-27" HeroName="sun">}} {{</ WeakAgainst/Config >}}
	
{{</ WeakAgainst >}}
