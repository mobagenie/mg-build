---
title: Build diggie Mobile Legends by Fαȥҽ~nikarus滅
post_highlight: "Player: Fαȥҽ~nikarus滅 WR: 70% Match: 571  Tier: S+ Tier Lane: Roam"
slug: build-mlbb-by-fnikarus
filename: "diggie-build-48"
categories: 
- Build 
- Mobile Legends
tags: 
- "fnikarus"
- ""
playername: "Fαȥҽ~nikarus滅"
cleanplayername: "fnikarus"
heroname: ""
images: ../p/images/buildk/diggie.png
draft: false
type: post
---

{{< HeroInfo HeroName="Phoveous" View="41284" Role="6" BP="24000" DM="499" Ticket="0" Player="Fαȥҽ~nikarus滅" CleanPlayerName="fnikarus" WR="70%" League="x 88" Match="571 " HeroTier="1" TierLabel="S+ Tier" LaneImg="2" LaneLabel="Roam" >}} {{< /HeroInfo >}}
 
{{< OffensiveBuild build1="CourageMask"  build2="ToughBoots" build3="NecklaceofDurance" build4="AntiqueCuirass" build5="AthenasShield" build6="Immortality" >}} {{</ OffensiveBuild >}}  

{{< BalancedBuild build1="ArcaneBoots"  build2="IceQueenWand" build3="FleetingTime" build4="Immortality" build5="DominanceIce" build6="AthenasShield" >}} {{</ BalancedBuild >}}  

{{< RecommendedSpells SpellName1="Flameshot" SpellImg1="9" SpellName2="Flicker" SpellImg2="10" >}} {{</ RecommendedSpells >}}   

{{< RecommendedEmblems EmblemName1="Support" EmblemImg1="8" EmblemName2="Mage" EmblemImg2="6" >}} {{</ RecommendedEmblems >}}   

{{< ChampionSkills SkillDesc1="<b>Young Again<br>Upon death, Diggie will become an egg. he can move and receive all-new chick abilities. Diggie cannot be targeted in egg form, and after a period of time, Diggie will revive." SkillImg1="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/88b36115e70c003ec5d81a67012aee28.png"  SkillDesc2="<b>Auto Alarm Bomb<br>Diggie throws an owl alarm in the designated direction. The alarm will automatically chase the enemies nearby, dealing 500<font color='#27C0C7'>( +120% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> to them and slowing them by 30%. If there is no enemy hero nearby, it will stay at the spot for 25s. This skill can have up to 3 charges. Its charging time is affected by CD Reduction." SkillImg2="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/92ee31edbaef8f8163d61fc63fb7d062.png"  SkillDesc3="<b>Reverse Time<br>Diggie marks a target and pulls it back to a designated location in 4s, dealing 150<font color='#27C0C7'>( +100% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> and slowing it by 80%. If enemies escape too far away, they will be pulled back and take damage immediately." SkillImg3="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/ae1901963b97702b73481b6b18486d8d.png"  SkillDesc4="<b>Time Journey<br>Diggie provides a shield that absorbs 400<font color='#27C0C7'>( +200% Total Magic Power)</font> damage to him and surrounding allies, and becomes immune to Control Effects. Lasts 3s. While casting the skill his Movement Speed increases by 50% for 0.5s." SkillImg4="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/e316d7911c30282b97332ffa1ad116cd.png"  >}} {{</ ChampionSkills >}}
	

{{< ChampionAttributes >}}

	{{< ChampionAttributes/Config img="mspeed.png" Attrib="Movement SPD:" AttribVal="250"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pattack" Attrib="Physical Attack" AttribVal="115"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mpower" Attrib="Magic Power" AttribVal="0"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pdefense" Attrib="Physical Defense" AttribVal="16"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mdefense" Attrib="Magical Defense" AttribVal="10"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hp" Attrib="HP" AttribVal="2351"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mana" Attrib="Mana:" AttribVal="490"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="aspeed" Attrib="Attack Speed:" AttribVal="0.8"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hregen" Attrib="Hp Regen" AttribVal="7.2"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mregen" Attrib="Mana Regen:" AttribVal="4"  >}} 
	{{</ ChampionAttributes/Config >}}
	
	
{{</ ChampionAttributes >}}


{{< FightingAbility >}}

	{{< FightingAbility/Config  Percentage="45"Label="Offense" >}} 
	{{</ FightingAbility/Config >}}		
	{{< FightingAbility/Config  Percentage="55"Label="Durability" >}} 
	{{</ FightingAbility/Config >}}
	{{< FightingAbility/Config  Percentage="75"Label="Ability Effects" >}} 
	{{</ FightingAbility/Config >}}
	
{{< FightingAbility >}}

{{< GetStory Story=" Scholars and thinkers from all over the world gather at the city of Antoinerei. It is here where the commonly overlooked Digger lives. Many don\'t give a second look to Digger due to his small frame, until they come upon his researches in chronoscience. Digger loves clocks, he believes that within these little mechanical toys lies many more yet to be discovered secrets. Through the use of his \"Time Nest\" Digger can control the flow of time. He is also able to release his friends from the physical shackles of time, taking them along with him. Beware though, for if you anger him, be prepared for the taste of a Hoot Hoot \'Time Bomb\'! " >}}  {{</ GetStory >}}

{{< StrongAgainst >}}

	{{< StrongAgainst/Config href="saber-build-3" HeroName="saber">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="aurora-build-36" HeroName="aurora">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="chou-build-26" HeroName="chou">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="franco-build-10" HeroName="franco">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="eudora-build-15" HeroName="eudora">}} {{</ StrongAgainst/Config >}}
	
{{</ StrongAgainst >}}

{{< WeakAgainst >}}

	{{< WeakAgainst/Config href="kagura-build-25" HeroName="kagura">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="lancelot-build-47" HeroName="lancelot">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="hayabusa-build-21" HeroName="hayabusa">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="helcurt-build-51" HeroName="helcurt">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="natalia-build-24" HeroName="natalia">}} {{</ WeakAgainst/Config >}}
	
{{</ WeakAgainst >}}
