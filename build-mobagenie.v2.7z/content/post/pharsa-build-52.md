---
title: Build pharsa Mobile Legends by ℓiмit | kįra้
post_highlight: "Player: ℓiмit | kįra้ WR: 86% Match: 453  Tier: A Tier Lane: Mid Lane"
slug: build-pharsa-mlbb-by-iit-kra
filename: "pharsa-build-52.html"
categories: 
- Build 
- Mobile Legends
tags: 
- "iit-kra"
- "pharsa"
playername: "ℓiмit | kįra้"
cleanplayername: "iit-kra"
heroname: "pharsa"
images: ../p/images/buildk/pharsa.png
draft: false
type: post
---

{{< HeroInfo HeroName="Phoveous" View="64873" Role="4" BP="32000" DM="599" Ticket="0" Player="ℓiмit | kįra้" CleanPlayerName="iit-kra" WR="86%" League="x 369" Match="453 " HeroTier="4" TierLabel="A Tier" LaneImg="3" LaneLabel="Mid Lane" >}} {{< /HeroInfo >}}
 
{{< OffensiveBuild build1="MagicShoes"  build2="ClockofDestiny" build3="LightningTruncheon" build4="NecklaceofDurance" build5="HolyCrystal" build6="DivineGlaive" >}} {{</ OffensiveBuild >}}  

{{< BalancedBuild build1="ArcaneBoots"  build2="LightningTruncheon" build3="HolyCrystal" build4="GlowingWand" build5="GeniusWand" build6="DivineGlaive" >}} {{</ BalancedBuild >}}  

{{< RecommendedSpells SpellName1="Flicker" SpellImg1="10" SpellName2="Flameshot" SpellImg2="9" >}} {{</ RecommendedSpells >}}   

{{< RecommendedEmblems EmblemName1="Mage" EmblemImg1="6" EmblemName2="Magical" EmblemImg2="2" >}} {{</ RecommendedEmblems >}}   

{{< ChampionSkills SkillDesc1="<b>Spiritual Unity<br>Every 10s, Verri enters the Hunting state, during which Pharsa&rsquo;s next attack deals extra 150 (+10*Hero Level) <font color='#27C0C7'>( +80% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> (the damage scales with levels) and slows the enemy hit by 60% for 1s." SkillImg1="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/2bf4d91d186d2909d93bcbbe19bfaa4c.png"  SkillDesc2="<b>Curse of Crow<br>Pharsa casts a spell to a target area, dealing 300<font color='#27C0C7'>( +120% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> to enemies within the area of effect and marking them. The mark lasts for 4s. When Pharsa hits a marked target with her other skills, the mark will stun the target for 1s and disappear." SkillImg2="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/7f4e27814e49dfb128e7c3517c91e990.png"  SkillDesc3="<b>Energy Impact<br>Pharsa releases magic energy in a designated direction, dealing 425<font color='#27C0C7'>( +145% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> to the enemy hit." SkillImg3="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/dd34d9aaa1d61fff94f38758301edf50.png"  SkillDesc4="<b>Feathered Air Strike<br>Pharsa flies into mid-air and launches air raids on the target area in the next 8s for 4 rounds. Each round deals 620<font color='#27C0C7'>( +160% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> to the enemy hit." SkillImg4="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/1ae3698c49e939133963490c284490c0.png"  >}} {{</ ChampionSkills >}}
	

{{< ChampionAttributes >}}

	{{< ChampionAttributes/Config img="mspeed.png" Attrib="Movement SPD:" AttribVal="240"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pattack" Attrib="Physical Attack" AttribVal="109"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mpower" Attrib="Magic Power" AttribVal="0"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pdefense" Attrib="Physical Defense" AttribVal="17"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mdefense" Attrib="Magical Defense" AttribVal="10"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hp" Attrib="HP" AttribVal="2421"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mana" Attrib="Mana:" AttribVal="490"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="aspeed" Attrib="Attack Speed:" AttribVal="0.7904"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hregen" Attrib="Hp Regen" AttribVal="6.8"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mregen" Attrib="Mana Regen:" AttribVal="3.6"  >}} 
	{{</ ChampionAttributes/Config >}}
	
	
{{</ ChampionAttributes >}}


{{< FightingAbility >}}

	{{< FightingAbility/Config  Percentage="40"Label="Offense" >}} 
	{{</ FightingAbility/Config >}}		
	{{< FightingAbility/Config  Percentage="52"Label="Durability" >}} 
	{{</ FightingAbility/Config >}}
	{{< FightingAbility/Config  Percentage="92"Label="Ability Effects" >}} 
	{{</ FightingAbility/Config >}}
	
{{< FightingAbility >}}

{{< GetStory Story=" The Crow people of Askati Forest are one of the oldest races to still exist in the Land of Dawn. This race was united by the Crow King Osana, under whose venerable leadership they perfected the art of Sky Magic.This unique school of magic allows its wielder to soar across the skies, and grants the ability to strike from enormous distances, however, only those who have had their blood \'awakened\' can use it. The noble Princess Pharsa was born with an unknown type of blood which was said to hold enormous potential if awakened, but as hard as they tried, the baffled people of her tribe failed to unleash its true power. Soon enough, Pharsa’s special blood became a burden, as ill-intentioned opportunists from across the land sought to reap it for their own benefit. On the day of Pharsa\'s wedding, the tyrannical witch Alice invaded the Askati Forest, mercilessly slaying countless Crows and leaving a smoldering trail of ruin in her wake. Numbed to the core by the carnage surrounding her, Pharsa dropped Osana\'s ancient crown to the floor. Her appearance began to change, as unprecedented power coursed through her veins -- her blood had been awakened. Pharsa\'s eyes clouded over, as one side of her hair turned pure white, and she soared into the sky to unleash a torrential assault of horrifying magical power fierce enough to drive Alice away. Verri, the love of her life, couldn’t bear to see his betrothed suffer a life of blindness alone, and chose to accompany Pharsa wherever she went, utilizing his own magic to become permanently linked to Pharsa, and allowing her to see through his eyes. Pharsa wishes her power had never been awakened, she wishes even more that her home had not been destroyed, but that witch took everything from her, and now it is time for revenge... " >}}  {{</ GetStory >}}

{{< StrongAgainst >}}

	{{< StrongAgainst/Config href="eudora-build-15" HeroName="eudora">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="zhask-build-50" HeroName="zhask">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="irithel-build-43" HeroName="irithel">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="minotaur-build-19" HeroName="minotaur">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="sun-build-27" HeroName="sun">}} {{</ StrongAgainst/Config >}}
	
{{</ StrongAgainst >}}

{{< WeakAgainst >}}

	{{< WeakAgainst/Config href="zilong-build-16" HeroName="zilong">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="fanny-build-17" HeroName="fanny">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="lancelot-build-47" HeroName="lancelot">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="freya-build-22" HeroName="freya">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="helcurt-build-51" HeroName="helcurt">}} {{</ WeakAgainst/Config >}}
	
{{</ WeakAgainst >}}
