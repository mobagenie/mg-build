---
title: Build fanny Mobile Legends by God Of Babannen
post_highlight: "Player: God Of Babannen WR: 88.0% Match: 4456  Tier: A Tier Lane: Jungle"
slug: build-fanny-mlbb-by-god-of-babannen
filename: "fanny-build-17.html"
categories: 
- Build 
- Mobile Legends
tags: 
- "god-of-babannen"
- "fanny"
playername: "God Of Babannen"
cleanplayername: "god-of-babannen"
heroname: "fanny"
images: ../p/images/buildk/fanny.png
draft: false
type: post
---

{{< HeroInfo HeroName="Phoveous" View="321133" Role="3" BP="24000" DM="499" Ticket="0" Player="God Of Babannen" CleanPlayerName="god-of-babannen" WR="88.0%" League="x 800" Match="4456 " HeroTier="4" TierLabel="A Tier" LaneImg="4" LaneLabel="Jungle" >}} {{< /HeroInfo >}}
 
{{< OffensiveBuild build1="RaptorMachete"  build2="ToughBoots" build3="BloodlustAxe" build4="BruteForceBreastplate" build5="BladeofDespair" build6="QueensWings" >}} {{</ OffensiveBuild >}}  

{{< BalancedBuild build1="BeastKiller"  build2="WarriorBoots" build3="BloodlustAxe" build4="AntiqueCuirass" build5="MaleficRoar" build6="AthenasShield" >}} {{</ BalancedBuild >}}  

{{< RecommendedSpells SpellName1="Retribution" SpellImg1="2" SpellName2="Retribution" SpellImg2="2" >}} {{</ RecommendedSpells >}}   

{{< RecommendedEmblems EmblemName1="Fighter" EmblemImg1="7" EmblemName2="Assassin" EmblemImg2="5" >}} {{</ RecommendedEmblems >}}   

{{< ChampionSkills SkillDesc1="<b>Air Superiority<br>According to her flying speed, Fanny's damage while flying is increased by 15% to 30% and leaves a <font color='#404495'>(Prey Mark)</font> on the target (Stack up to 2 times). For Each stack of <font color='#404495'>(Prey Mark)</font> the target has, Fanny regens 10 energy when she deals damage to it. (Energy regen effect decays if she deals damage to multiple enemy heroes in a short time.)" SkillImg1="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/e6fe7f7fdba5cd1084508a770e8fc759.png"  SkillDesc2="<b>Tornado Strike<br>Fanny whirls her blade, dealing 280<font color='#D58E1F'>( +90% Total Physical ATK)</font> <font color='#C53535'>(Physical Damage)</font> to nearby enemies." SkillImg2="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/7dbd8e7f220c6ab3189e92a888e92564.png"  SkillDesc3="<b>Steel Cable<br>Fanny throws out a cable that draws her to the first obstacle that it touches. Each successive use of this skill within 2s decreases its energy cost by 1 and changes her flying direction. If energy is sufficient and she hits an enemy while flying, <font color='#404495'>(Tornado Strike)</font> will be triggered." SkillImg3="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/75f1af588764eea173af258b1b6a51b0.png"  SkillDesc4="<b>Cut Throat<br>Fanny initiates a quick attack on an enemy, dealing 500<font color='#D58E1F'>( +240% Extra Physical ATK)</font> <font color='#C53535'>(Physical Damage)</font>. Each stack of <font color='#404495'>(Prey Mark)</font> of enemies will increase her damage by 20%." SkillImg4="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/09904c06a8f80b114436167599ad1251.png"  >}} {{</ ChampionSkills >}}
	

{{< ChampionAttributes >}}

	{{< ChampionAttributes/Config img="mspeed.png" Attrib="Movement SPD:" AttribVal="265"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pattack" Attrib="Physical Attack" AttribVal="126"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mpower" Attrib="Magic Power" AttribVal="0"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pdefense" Attrib="Physical Defense" AttribVal="19"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mdefense" Attrib="Magical Defense" AttribVal="10"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hp" Attrib="HP" AttribVal="2526"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mana" Attrib="Mana:" AttribVal="0"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="aspeed" Attrib="Attack Speed:" AttribVal="0.894"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hregen" Attrib="Hp Regen" AttribVal="6.6"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mregen" Attrib="Mana Regen:" AttribVal="0"  >}} 
	{{</ ChampionAttributes/Config >}}
	
	
{{</ ChampionAttributes >}}


{{< FightingAbility >}}

	{{< FightingAbility/Config  Percentage="85"Label="Offense" >}} 
	{{</ FightingAbility/Config >}}		
	{{< FightingAbility/Config  Percentage="60"Label="Durability" >}} 
	{{</ FightingAbility/Config >}}
	{{< FightingAbility/Config  Percentage="50"Label="Ability Effects" >}} 
	{{</ FightingAbility/Config >}}
	
{{< FightingAbility >}}

{{< GetStory Story=" Despite just being a human, Fanny never gave up on her dream of flying. She fashioned a kind of steel grappling hook for herself in the hopes of using it to grab onto cliff faces and soar between mountain peaks. After countless training sessions in live environments, Fanny has finally mastered this technique. Folks who have seen her soaring through the air refer to her as the Blade of Freedom. " >}}  {{</ GetStory >}}

{{< StrongAgainst >}}

	{{< StrongAgainst/Config href="layla-build-18" HeroName="layla">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="karina-build-8" HeroName="karina">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="estes-build-34" HeroName="estes">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="natalia-build-24" HeroName="natalia">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="bruno-build-12" HeroName="bruno">}} {{</ StrongAgainst/Config >}}
	
{{</ StrongAgainst >}}

{{< WeakAgainst >}}

	{{< WeakAgainst/Config href="ruby-build-29" HeroName="ruby">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="chou-build-26" HeroName="chou">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="eudora-build-15" HeroName="eudora">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="franco-build-10" HeroName="franco">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="akai-build-9" HeroName="akai">}} {{</ WeakAgainst/Config >}}
	
{{</ WeakAgainst >}}
