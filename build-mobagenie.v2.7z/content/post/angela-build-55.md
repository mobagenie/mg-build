---
title: Build angela Mobile Legends by CΣ | Ꭰejakub
post_highlight: "Player: CΣ | Ꭰejakub WR: 83% Match: 586  Tier: A+ Tier Lane: Roam"
slug: build-angela-mlbb-by-c-ejakub
filename: "angela-build-55.html"
categories: 
- Build 
- Mobile Legends
tags: 
- "c-ejakub"
- "angela"
playername: "CΣ | Ꭰejakub"
cleanplayername: "c-ejakub"
heroname: "angela"
images: ../p/images/buildk/angela.png
draft: false
type: post
---

{{< HeroInfo HeroName="Phoveous" View="88487" Role="6" BP="24000" DM="499" Ticket="0" Player="CΣ | Ꭰejakub" CleanPlayerName="c-ejakub" WR="83%" League="x 452" Match="586 " HeroTier="3" TierLabel="A+ Tier" LaneImg="2" LaneLabel="Roam" >}} {{< /HeroInfo >}}
 
{{< OffensiveBuild build1="CourageMask"  build2="MagicShoes" build3="EnchantedTalisman" build4="Oracle" build5="AntiqueCuirass" build6="Immortality" >}} {{</ OffensiveBuild >}}  

{{< BalancedBuild build1="DemonShoes"  build2="CourageMask" build3="EnchantedTalisman" build4="FleetingTime" build5="AthenasShield" build6="Immortality" >}} {{</ BalancedBuild >}}  

{{< RecommendedSpells SpellName1="Flicker" SpellImg1="10" SpellName2="Flameshot" SpellImg2="9" >}} {{</ RecommendedSpells >}}   

{{< RecommendedEmblems EmblemName1="Support" EmblemImg1="8" EmblemName2="Mage" EmblemImg2="6" >}} {{</ RecommendedEmblems >}}   

{{< ChampionSkills SkillDesc1="<b>Smart Heart<br>Each time Angela uses a skill, her Movement Speed increases by 15% for 4s, up to 30%. The attached ally also enjoys the Movement Speed Bonus." SkillImg1="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/a8fe93510e0f6c45a2c2be63cf436aa0.png"  SkillDesc2="<b>Love Waves<br>Angela releases Love Energy in the targeted direction, dealing 170<font color='#27C0C7'>( +80% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> and adding <font color='#404495'>(Lover's Mark)</font> to enemies. Each stack of <font color='#404495'>(Lover's Mark)</font> increases the amount of damage the target takes by 20%, and slows them by 8% for 3s. This effect can be stacked up to 5 times. Restores 150<font color='#27C0C7'>( +60% Total Magic Power)</font> HP to allies if allies are hit. Up to 5 charges can be stored (recharge time is affected by CD Reduction)." SkillImg2="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/320477295b9dcf7821cbc4af4e61642d.png"  SkillDesc3="<b>Puppet-on-a-String<br>Angela releases a puppet string to the chosen target, dealing 300<font color='#27C0C7'>( +40% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> and gradually slowing the target by up to 80%. If the target is still connected to the string after 3s, they will be immobilized for 1.5s and take 450<font color='#27C0C7'>( +60% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font>. Each stack of <font color='#404495'>(Lover's Mark)</font> increases the Final Damage by 20%." SkillImg3="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/20cd666c45a15712acef5d2b4399534b.png"  SkillDesc4="<b>Heartguard<br>Angela generates a shield for any chosen ally on the map, which absorbs up to 1200<font color='#27C0C7'>( +200% Total Magic Power)</font> damage for the next 6s. After a while, Angela will be attached to the ally for 12s. During the <font color='#404495'>(Attaching State)</font>, Angela can use all her skills without costing Mana. Once this skill is used again or the ally is dead, Angela will be withdrawn from the ally." SkillImg4="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/ae9bdffba93f817a44139e9a8b2a071d.png"  >}} {{</ ChampionSkills >}}
	

{{< ChampionAttributes >}}

	{{< ChampionAttributes/Config img="mspeed.png" Attrib="Movement SPD:" AttribVal="240"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pattack" Attrib="Physical Attack" AttribVal="115"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mpower" Attrib="Magic Power" AttribVal="0"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pdefense" Attrib="Physical Defense" AttribVal="15"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mdefense" Attrib="Magical Defense" AttribVal="10"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hp" Attrib="HP" AttribVal="2421"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mana" Attrib="Mana:" AttribVal="515"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="aspeed" Attrib="Attack Speed:" AttribVal="0.792"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hregen" Attrib="Hp Regen" AttribVal="6.8"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mregen" Attrib="Mana Regen:" AttribVal="3.6"  >}} 
	{{</ ChampionAttributes/Config >}}
	
	
{{</ ChampionAttributes >}}


{{< FightingAbility >}}

	{{< FightingAbility/Config  Percentage="38"Label="Offense" >}} 
	{{</ FightingAbility/Config >}}		
	{{< FightingAbility/Config  Percentage="45"Label="Durability" >}} 
	{{</ FightingAbility/Config >}}
	{{< FightingAbility/Config  Percentage="88"Label="Ability Effects" >}} 
	{{</ FightingAbility/Config >}}
	
{{< FightingAbility >}}

{{< GetStory Story=" Dr. Baker was one of the founders of Lab 1718, an institution created with the aim of bringing peace to the world. But as his co-founders fell deeper and deeper into their depraved human weaponization experiments, Dr. Baker felt he had no choice but to leave and pursue a new project. Renouncing the questionable ethics of human experimentation, he endeavored to create a new kind of lifeform, solely from a mechanical skeleton, puppet strings, and synthetic skin, and finally, a new generation of artificial life was born. Dr. Baker firmly believed that love and hope were the greatest inventions of mankind, so he programmed the world\'s most moving stories into the heart of his new creation. One bright morning, Peace Android Prototype 1 awakened from her bed, and Dr. Baker bestowed upon this adorable mechanical angel, the name Angela. Angela followed Dr. Baker\'s tutelage, studying hard to understand the world, and hoping to meet the doctor\'s high expectations. However, their peaceful life together was soon cut short. When the mad scientists of Lab 1718 heard rumors that Dr. Baker had created a living soul outside of a human body, they couldn\'t believe it. They convinced themselves that Baker had betrayed them, keeping this knowledge to himself before fleeing, and so they ordered Dr. Baker\'s past creations, Alpha and Beta to hunt down Dr. Baker and his creation. As their pursuers were just about to close in on them, Dr. Baker placed Angela into a flight capsule, instructing her to seek out his good friend Dr. Rooney. However, the flight capsule was struck down a terrible thunderstorm, and landed in a remote corner of the Land of Dawn. Emerging from the wreckage, Angela began her journey to find Dr. Rooney, and save her father. " >}}  {{</ GetStory >}}

{{< StrongAgainst >}}

	{{< StrongAgainst/Config href="vexana-build-38" HeroName="vexana">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="eudora-build-15" HeroName="eudora">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="gord-build-23" HeroName="gord">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="estes-build-34" HeroName="estes">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="layla-build-18" HeroName="layla">}} {{</ StrongAgainst/Config >}}
	
{{</ StrongAgainst >}}

{{< WeakAgainst >}}

	{{< WeakAgainst/Config href="lancelot-build-47" HeroName="lancelot">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="lesley-build-53" HeroName="lesley">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="harley-build-42" HeroName="harley">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="kagura-build-25" HeroName="kagura">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="natalia-build-24" HeroName="natalia">}} {{</ WeakAgainst/Config >}}
	
{{</ WeakAgainst >}}
