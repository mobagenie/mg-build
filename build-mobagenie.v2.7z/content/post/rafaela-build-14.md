---
title: Build rafaela Mobile Legends by ЅΣΓHΛП
post_highlight: "Player: ЅΣΓHΛП WR: 82.6% Match: 637  Tier: S Tier Lane: Roam"
slug: build-rafaela-mlbb-by-h
filename: "rafaela-build-14.html"
categories: 
- Build 
- Mobile Legends
tags: 
- "h"
- "rafaela"
playername: "ЅΣΓHΛП"
cleanplayername: "h"
heroname: "rafaela"
images: ../p/images/buildk/rafaela.png
draft: false
type: post
---

{{< HeroInfo HeroName="Phoveous" View="71054" Role="6" BP="6500" DM="254" Ticket="0" Player="ЅΣΓHΛП" CleanPlayerName="h" WR="82.6%" League="x 576" Match="637 " HeroTier="2" TierLabel="S Tier" LaneImg="2" LaneLabel="Roam" >}} {{< /HeroInfo >}}
 
{{< OffensiveBuild build1="CourageMask"  build2="DemonShoes" build3="IceQueenWand" build4="AthenasShield" build5="Immortality" build6="AntiqueCuirass" >}} {{</ OffensiveBuild >}}  

{{< BalancedBuild build1="DemonShoes"  build2="CourageMask" build3="ThunderBelt" build4="AthenasShield" build5="NecklaceofDurance" build6="Immortality" >}} {{</ BalancedBuild >}}  

{{< RecommendedSpells SpellName1="Revitalize" SpellImg1="5" SpellName2="Flicker" SpellImg2="10" >}} {{</ RecommendedSpells >}}   

{{< RecommendedEmblems EmblemName1="Support" EmblemImg1="8" EmblemName2="Mage" EmblemImg2="6" >}} {{</ RecommendedEmblems >}}   

{{< ChampionSkills SkillDesc1="<b>Deity Penalization<br>Rafaela penalizes the target who has killed her (the target should be within a certain range). She charges for 2s and then sends the penalization power to the target, dealing <font color='#E5CB19'>(True Damage)</font> equal to 20% of the target's Max HP. It can be blocked by other enemy heroes. This skill works only on enemy heroes." SkillImg1="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/d31cd3b4cfac274932ac9ba37d3e74f8.png"  SkillDesc2="<b>Light of Retribution<br>Rafaela uses the power of Holy Light to deal 225<font color='#27C0C7'>( +120% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> to three nearest enemies, revealing them for a short period of time and slowing them by 40% for 1.5s. If this skill hits the same target multiple times within 5s, its damage will be increased by 20% after each hit. Stacks up to 3 times." SkillImg2="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/50d4de53d218be554607f9ab8f5c45ac.png"  SkillDesc3="<b>Holy Healing<br>Rafaela summons Holy Light to regenerate 250<font color='#27C0C7'>( +50% Total Magic Power)</font> HP for herself and the most-injured nearby ally. Regenerates 100<font color='#27C0C7'>( +25% Total Magic Power)</font> HP for other nearby allied heroes. Increases their Movement Speed by 50% within the following 1.5s." SkillImg3="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/2eb22acaa248513f322e16e5359049c7.png"  SkillDesc4="<b>Holy Baptism<br>Rafaela uses the power of Holy Light to punish enemies in front of her, dealing 460<font color='#27C0C7'>( +120% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> and stunning them for 1.5s." SkillImg4="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/76eacd7246b60231b0d889c216f0a345.png"  >}} {{</ ChampionSkills >}}
	

{{< ChampionAttributes >}}

	{{< ChampionAttributes/Config img="mspeed.png" Attrib="Movement SPD:" AttribVal="245"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pattack" Attrib="Physical Attack" AttribVal="117"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mpower" Attrib="Magic Power" AttribVal="0"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pdefense" Attrib="Physical Defense" AttribVal="15"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mdefense" Attrib="Magical Defense" AttribVal="10"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hp" Attrib="HP" AttribVal="2441"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mana" Attrib="Mana:" AttribVal="545"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="aspeed" Attrib="Attack Speed:" AttribVal="0.792"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hregen" Attrib="Hp Regen" AttribVal="7.2"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mregen" Attrib="Mana Regen:" AttribVal="4.6"  >}} 
	{{</ ChampionAttributes/Config >}}
	
	
{{</ ChampionAttributes >}}


{{< FightingAbility >}}

	{{< FightingAbility/Config  Percentage="50"Label="Offense" >}} 
	{{</ FightingAbility/Config >}}		
	{{< FightingAbility/Config  Percentage="52"Label="Durability" >}} 
	{{</ FightingAbility/Config >}}
	{{< FightingAbility/Config  Percentage="70"Label="Ability Effects" >}} 
	{{</ FightingAbility/Config >}}
	
{{< FightingAbility >}}

{{< GetStory Story=" Rafaela is an angel capable of miraculously healing anything. It is said that when she appears, all pain suddenly vanishes, all wounds instantly heal, and all evil disperses like rain clouds when the sun comes out. Now Rafaela has descended upon the Land of Dawn in the hopes of using her miraculous powers to restore peace to the land. " >}}  {{</ GetStory >}}

{{< StrongAgainst >}}

	{{< StrongAgainst/Config href="alice-build-4" HeroName="alice">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="cyclops-build-33" HeroName="cyclops">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="sun-build-27" HeroName="sun">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="nana-build-5" HeroName="nana">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="bane-build-11" HeroName="bane">}} {{</ StrongAgainst/Config >}}
	
{{</ StrongAgainst >}}

{{< WeakAgainst >}}

	{{< WeakAgainst/Config href="karina-build-8" HeroName="karina">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="saber-build-3" HeroName="saber">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="hayabusa-build-21" HeroName="hayabusa">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="natalia-build-24" HeroName="natalia">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="moskov-build-31" HeroName="moskov">}} {{</ WeakAgainst/Config >}}
	
{{</ WeakAgainst >}}
