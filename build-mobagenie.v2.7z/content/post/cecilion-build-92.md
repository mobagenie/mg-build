---
title: Build cecilion Mobile Legends by ᎷᏗᏖᏗᏕᏂᎥᎩᏬᏒᎥ
post_highlight: "Player: ᎷᏗᏖᏗᏕᏂᎥᎩᏬᏒᎥ WR: 82% Match: 106  Tier: A Tier Lane: Mid Lane"
slug: build-cecilion-mlbb-by
filename: "cecilion-build-92.html"
categories: 
- Build 
- Mobile Legends
tags: 
- ""
- "cecilion"
playername: "ᎷᏗᏖᏗᏕᏂᎥᎩᏬᏒᎥ"
cleanplayername: ""
heroname: "cecilion"
images: ../p/images/buildk/cecilion.png
draft: false
type: post
---

{{< HeroInfo HeroName="Phoveous" View="133599" Role="4" BP="32000" DM="599" Ticket="0" Player="ᎷᏗᏖᏗᏕᏂᎥᎩᏬᏒᎥ" CleanPlayerName="" WR="82%" League="x 231" Match="106 " HeroTier="4" TierLabel="A Tier" LaneImg="3" LaneLabel="Mid Lane" >}} {{< /HeroInfo >}}
 
{{< OffensiveBuild build1="DemonShoes"  build2="LightningTruncheon" build3="ConcentratedEnergy" build4="HolyCrystal" build5="GeniusWand" build6="BloodWings" >}} {{</ OffensiveBuild >}}  

{{< BalancedBuild build1="DemonShoes"  build2="LightningTruncheon" build3="ConcentratedEnergy" build4="AthenasShield" build5="QueensWings" build6="Immortality" >}} {{</ BalancedBuild >}}  

{{< RecommendedSpells SpellName1="Flicker" SpellImg1="10" SpellName2="Retribution" SpellImg2="2" >}} {{</ RecommendedSpells >}}   

{{< RecommendedEmblems EmblemName1="Mage" EmblemImg1="6" EmblemName2="Magical" EmblemImg2="2" >}} {{</ RecommendedEmblems >}}   

{{< ChampionSkills SkillDesc1="<b>Overflowing<br>Cecilion will increase his max mana by 8 each time his skill hits an enemy target. This effect cools down in 1s. Cecilion has higher max mana and mana regen speed, and his skill damage scales with his max mana." SkillImg1="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/271b31413ede078dd92d7124ed88f0fd.png"  SkillDesc2="<b>Bat Impact<br>Cecilion orders a giant bat to dive in a designated direction, dealing 100<font color='#27C0C7'>( +80% Total Magic Power)</font><font color='#404495'>( +5% Total Mana)</font> <font color='#3B69FF'>(Magic Damage)</font> to enemies on the path. The giant bat will stay at its destination and launch another attack, dealing 200<font color='#27C0C7'>( +160% Total Magic Power)</font><font color='#404495'>( +10% Total Mana)</font> <font color='#3B69FF'>(Magic Damage)</font> to enemies and triggering <font color='#404495'>(Overflowing)</font> extra 1 time. In 6s, every time Cecilion casts this skill, the mana cost will be increased by 1.8 time(s) (capped at 4 times). While casting this skill, he also gains 30% Movement Speed for 1s." SkillImg2="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/2fd205cb0a0a806ec62c9db4ad279bad.png"  SkillDesc3="<b>Sanguine Claws<br>Cecilion summons a pair of claws in a designated position that will run to each other, slowing down the enemies on the path. After a short delay, the claws pull the enemies to the center, immobilizing them for 1s and dealing 200<font color='#27C0C7'>( +45% Total Magic Power)</font><font color='#404495'>( +1% Total Mana)</font> <font color='#3B69FF'>(Magic Damage)</font>." SkillImg3="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/82e2901e8947af4ea89a620f9ba2cedf.png"  SkillDesc4="<b>Bats Feast<br>Cecilion unleashes Blood Demon power, increasing his Movement Speed by 60% (decaying rapidly over 1.5s) and gaining immunity to slow effects. Meanwhile, he shoots 40 bolts of blood energy at the enemies nearby, each dealing 35<font color='#27C0C7'>( +8% Total Magic Power)</font><font color='#404495'>( +0% Total Mana)</font> <font color='#3B69FF'>(Magic Damage)</font> and slowing them by 3% (up to 30%) for 1s. Hitting an enemy heals him for 10 and 1% of his lost HP." SkillImg4="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/0a352aae21a0fadc122c2747247abde8.png"  >}} {{</ ChampionSkills >}}
	

{{< ChampionAttributes >}}

	{{< ChampionAttributes/Config img="mspeed.png" Attrib="Movement SPD:" AttribVal="255"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pattack" Attrib="Physical Attack" AttribVal="105"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mpower" Attrib="Magic Power" AttribVal="0"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pdefense" Attrib="Physical Defense" AttribVal="20"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mdefense" Attrib="Magical Defense" AttribVal="10"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hp" Attrib="HP" AttribVal="2516"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mana" Attrib="Mana:" AttribVal="700"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="aspeed" Attrib="Attack Speed:" AttribVal="0.8"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hregen" Attrib="Hp Regen" AttribVal="6.8"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mregen" Attrib="Mana Regen:" AttribVal="6"  >}} 
	{{</ ChampionAttributes/Config >}}
	
	
{{</ ChampionAttributes >}}


{{< FightingAbility >}}

	{{< FightingAbility/Config  Percentage="40"Label="Offense" >}} 
	{{</ FightingAbility/Config >}}		
	{{< FightingAbility/Config  Percentage="43"Label="Durability" >}} 
	{{</ FightingAbility/Config >}}
	{{< FightingAbility/Config  Percentage="82"Label="Ability Effects" >}} 
	{{</ FightingAbility/Config >}}
	
{{< FightingAbility >}}

{{< GetStory Story=" Many years ago, enjoying the night opera performed by Cecilion was the most popular form of entertainment for the people of Castle Aberleen. It was always full house at the theatre each time this most famous opera actor performed. Everyone was attracted by his indescribable beauty and talent. However, the applause, love and cheers from human beings didn’t make Cecilion feel happy. He was one of the Blood Demons, and it was hard for him to open his mind to humans." >}}  {{</ GetStory >}}

{{< StrongAgainst >}}

	{{< StrongAgainst/Config href="masha-build-86" HeroName="masha">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="kimmy-build-70" HeroName="kimmy">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="carmilla-build-91" HeroName="carmilla">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="valir-build-57" HeroName="valir">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="lunox-build-67" HeroName="lunox">}} {{</ StrongAgainst/Config >}}
	
{{</ StrongAgainst >}}

{{< WeakAgainst >}}

	{{< WeakAgainst/Config href="gusion-build-56" HeroName="gusion">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="wanwan-build-89" HeroName="wanwan">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="silvanna-build-90" HeroName="silvanna">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="ling-build-88" HeroName="ling">}} {{</ WeakAgainst/Config >}}
	
	
{{</ WeakAgainst >}}
