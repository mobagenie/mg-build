---
title: Build kaja Mobile Legends by Fαȥҽ~nikarus滅
post_highlight: "Player: Fαȥҽ~nikarus滅 WR: 75% Match: 250  Tier: S Tier Lane: Roam"
slug: build-kaja-mlbb-by-fnikarus
filename: "kaja-build-62.html"
categories: 
- Build 
- Mobile Legends
tags: 
- "fnikarus"
- "kaja"
playername: "Fαȥҽ~nikarus滅"
cleanplayername: "fnikarus"
heroname: "kaja"
images: ../p/images/buildk/kaja.png
draft: false
type: post
---

{{< HeroInfo HeroName="Phoveous" View="74347" Role="6" BP="32000" DM="599" Ticket="0" Player="Fαȥҽ~nikarus滅" CleanPlayerName="fnikarus" WR="75%" League="x 100" Match="250 " HeroTier="2" TierLabel="S Tier" LaneImg="2" LaneLabel="Roam" >}} {{< /HeroInfo >}}
 
{{< OffensiveBuild build1="DemonShoes"  build2="LightningTruncheon" build3="CalamityReaper" build4="GlowingWand" build5="AthenasShield" build6="Immortality" >}} {{</ OffensiveBuild >}}  

{{< BalancedBuild build1="DemonShoes"  build2="FleetingTime" build3="ThunderBelt" build4="AthenasShield" build5="Immortality" build6="QueensWings" >}} {{</ BalancedBuild >}}  

{{< RecommendedSpells SpellName1="Flicker" SpellImg1="10" SpellName2="Execute" SpellImg2="1" >}} {{</ RecommendedSpells >}}   

{{< RecommendedEmblems EmblemName1="Mage" EmblemImg1="6" EmblemName2="Support" EmblemImg2="8" >}} {{</ RecommendedEmblems >}}   

{{< ChampionSkills SkillDesc1="<b>Wrath Sanction<br>Kaja achieves Wrath Sanction every 6s. His next Basic Attack will send a lightning to enemies, dealing <font color='#3B69FF'>(Magic Damage)</font> equal to 100<font color='#27C0C7'>( +100% Total Magic Power)</font> plus 4% of targets' Max HP. The lightning will hit enemies nearby as well (up to 3 times). Increases damage by 200% of targets' Max HP on minions and creeps." SkillImg1="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/26dd0cc96757d1a91a709f08ffc02e1e.png"  SkillDesc2="<b>Ring of Order<br>Kaja releases a Ringed Electric Blade that quickly expands and contracts. Any enemy target comes in contact with the electric ring will receive 135<font color='#27C0C7'>( +70% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> and be slowed by 30% for 1s. Each time this deals damage to enemies, the CD of Wrath Sanction will be reduced by 1s." SkillImg2="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/e0504b84a58a5b817204547e5f9a4179.png"  SkillDesc3="<b>Lightning Bomb<br>Kaja moves towards the designated direction and leaves 3 lightning bombs along the way. When enemy units touch the lightning bombs, they will take 200<font color='#27C0C7'>( +120% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font>." SkillImg3="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/0fd6bf12f42942c2079d81ba35423e50.png"  SkillDesc4="<b>Divine Judgment<br>Kaja deals 300<font color='#27C0C7'>( +150% Total Magic Power)</font> <font color='#3B69FF'>(Magic Damage)</font> to a designated enemy hero and suppresses the target for 1.5s. During that time, the enemy hero&rsquo;s Magic Defense is reduced by 10. Kaja absorbs 2x of the target enemy hero&rsquo;s lost Magic Defense." SkillImg4="http://akmwebstatic.yuanzhanapp.com/web/mlweb/image/res/miya/skill/cf3205aa000b788fa0ac904b71ef664d.png"  >}} {{</ ChampionSkills >}}
	

{{< ChampionAttributes >}}

	{{< ChampionAttributes/Config img="mspeed.png" Attrib="Movement SPD:" AttribVal="270"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pattack" Attrib="Physical Attack" AttribVal="120"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mpower" Attrib="Magic Power" AttribVal="0"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="pdefense" Attrib="Physical Defense" AttribVal="16"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mdefense" Attrib="Magical Defense" AttribVal="10"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hp" Attrib="HP" AttribVal="2609"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mana" Attrib="Mana:" AttribVal="400"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="aspeed" Attrib="Attack Speed:" AttribVal="0.842"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="hregen" Attrib="Hp Regen" AttribVal="10.4"  >}} 
	{{</ ChampionAttributes/Config >}}
	{{< ChampionAttributes/Config img="mregen" Attrib="Mana Regen:" AttribVal="2.4"  >}} 
	{{</ ChampionAttributes/Config >}}
	
	
{{</ ChampionAttributes >}}


{{< FightingAbility >}}

	{{< FightingAbility/Config  Percentage="48"Label="Offense" >}} 
	{{</ FightingAbility/Config >}}		
	{{< FightingAbility/Config  Percentage="80"Label="Durability" >}} 
	{{</ FightingAbility/Config >}}
	{{< FightingAbility/Config  Percentage="82"Label="Ability Effects" >}} 
	{{</ FightingAbility/Config >}}
	
{{< FightingAbility >}}

{{< GetStory Story=" The Celestial Palace, home of the gods, was once a bustling city patrolled by innumerable Nazar guardians. Any demon who dared approach the city would be overwhelmed by their peerless flying speed and bound by their fearsome lightning whips which would strip their victims of all magical abilities. No demon could escape when pursued by these divine warriors, and thus perpetual peace was maintained in the Celestial Palace. As their leader, Kaja was able to refine the power of lighting into pure energy to control as he so desired, inflicting catastrophic damage to all enemies who faced him, and was charged with directly protecting the ruler of the city. Countless eons ago, after the ruler completed the creation of the city's guardians and departed, the city gradually fell into a state of ruin. When Uranus was activated, the ruler of the Celestial Palace handed down new orders to the Nazar -- to drive the evil demons from the city and rebuild the Celestial Palace in anticipation of the master's return. " >}}  {{</ GetStory >}}

{{< StrongAgainst >}}

	{{< StrongAgainst/Config href="natalia-build-24" HeroName="natalia">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="fanny-build-17" HeroName="fanny">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="harley-build-42" HeroName="harley">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="chou-build-26" HeroName="chou">}} {{</ StrongAgainst/Config >}}
	{{< StrongAgainst/Config href="aurora-build-36" HeroName="aurora">}} {{</ StrongAgainst/Config >}}
	
{{</ StrongAgainst >}}

{{< WeakAgainst >}}

	{{< WeakAgainst/Config href="helcurt-build-51" HeroName="helcurt">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="grock-build-44" HeroName="grock">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="akai-build-9" HeroName="akai">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="martis-build-58" HeroName="martis">}} {{</ WeakAgainst/Config >}}
	{{< WeakAgainst/Config href="gusion-build-56" HeroName="gusion">}} {{</ WeakAgainst/Config >}}
	
{{</ WeakAgainst >}}
