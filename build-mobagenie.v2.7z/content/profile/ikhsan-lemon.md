---
title: "Ikhsan Lemon"
post_highlight: ""
author: MobaGenie
date: 2021-07-26T03:33:10+07:00
PublishDate: 2021-07-26T03:33:10+07:00
Lastmod: 2021-07-26T03:33:10+07:00
slug: ikhsan-lemon
filename: ""
categories: 
- Build 
- Mobile Legends
tags: 
- ""
- ""
playername: "Ikhsan Lemon"
cleanplayername: "ikhsan-lemon"
heroname: ""
images: ../p/images/buildk/.png
draft: false
layout: profile
type: profile
profileplayer: true
proplayer: true
team: Team RRQ
ytvideoid: Iz8myOddk5A
ign: RRQ.Lemon
yt: UCuVxJ829ysWH2OhZJiWdnbg
fb: ikhsanlemon
ig: ikhsan_lemon
tw: rrq_lemon_
bio: RRQ Lemon mengawali karirnya sebagai pro gamer sejak kemunculan game Mobile Legends yaitu pada 2016 silam. Kemudian setahun setelahnya ia mulai masuk dalam squad bernama RRQ. Selain itu, memang sejak kecil ia sangat tertarik pada semua jenis game.
---

{{< profile/player/playerinfo name="Ikhsan Lemon" cleanname="ikhsan-lemon" bio="RRQ Lemon mengawali karirnya sebagai pro gamer sejak kemunculan game Mobile Legends yaitu pada 2016 silam. Kemudian setahun setelahnya ia mulai masuk dalam squad bernama RRQ. Selain itu, memang sejak kecil ia sangat tertarik pada semua jenis game." >}} {{</ profile/player/playerinfo >}}
 
