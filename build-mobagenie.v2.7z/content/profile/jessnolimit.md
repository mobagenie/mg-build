---
title: "Jessnolimit1"
post_highlight: ""
author: MobaGenie
date: 2021-07-25T21:51:54+07:00
PublishDate: 2021-07-25T21:51:54+07:00
Lastmod: 2021-07-25T21:51:54+07:00
slug: jessnolimit
filename: ""
categories: 
- Build 
- Mobile Legends
tags: 
- ""
- ""
playername: "Jess No Limit"
cleanplayername: "jessnolimit"
heroname: ""
images: ../p/images/buildk/.png
draft: false
layout: profile
type: profile
profileplayer: true
proplayer: true
team: Evos Esports (ex)
ytvideoid: 1xbIGJsnlHQ
ign: JessNoLimit
yt: UCvh1at6xpV1ytYOAzxmqUsA
fb: jessnolimit.id
ig: jessnolimit
tw: _jessnolimit
bio: Tobias Justin, yang dikenal secara profesional sebagai Jess No Limit (lahir di Kota Jakarta, Indonesia, 5 Februari 1996; umur 25 tahun) adalah seorang pemain permainan daring, streamer, dan YouTuber berkebangsaan Indonesia.
---

{{< profile/player/playerinfo name="Jess no Limit" cleanname="jessnolimit" bio="Tobias Justin, yang dikenal secara profesional sebagai Jess No Limit (lahir di Kota Jakarta, Indonesia, 5 Februari 1996; umur 25 tahun) adalah seorang pemain permainan daring, streamer, dan YouTuber berkebangsaan Indonesia." >}} {{</ profile/player/playerinfo >}}
 
