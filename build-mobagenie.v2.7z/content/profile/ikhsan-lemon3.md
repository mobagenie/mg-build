---
title: "Ikhsan Lemon3"
post_highlight: ""
author: MobaGenie
date: 2021-07-26T04:35:12+07:00
PublishDate: 2021-07-26T04:35:12+07:00
Lastmod: 2021-07-26T04:35:12+07:00
slug: ikhsan-lemon3
categories: 
- Profile 
- Player
- Biodata
tags: 
- "ikhsan-lemon3"
- "Ikhsan Lemon3"
- Profile 
- Player
- Biodata
playername: "Ikhsan Lemon3"
cleanplayername: "ikhsan-lemon3"
images: https://res.cloudinary.com/drlhixyyd/image/fetch/c_thumb,g_face,h_150,w_150/https://cdn2-build.mobagenie.my.id/p/images/banner/player/full/ikhsan-lemon3.jpg
draft: false
layout: profile
type: profile
profileplayer: true
proplayer: false
team: 
ytvideoid: 
ign: 
yt: 
fb: 
ig: 
tw: 
bio:
---

{{< profile/player/playerinfo name="Ikhsan Lemon3" cleanname="ikhsan-lemon3" bio="" >}} {{</ profile/player/playerinfo >}}