---
title: "Markocop"
post_highlight: ""
author: MobaGenie
date: 2021-07-26T04:42:12+07:00
PublishDate: 2021-07-26T04:42:12+07:00
Lastmod: 2021-07-26T04:42:12+07:00
slug: markocop
categories: 
- Profile 
- Player
- Biodata
tags: 
- "markocop"
- "Markocop"
- Profile 
- Player
- Biodata
playername: "Markocop"
cleanplayername: "markocop"
images: https://res.cloudinary.com/drlhixyyd/image/fetch/https://cdn2-build.mobagenie.my.id/p/images/banner/player/full/markocop.jpg
draft: false
layout: profile
type: profile
profileplayer: true
proplayer: false
team: 
ytvideoid: 
ign: 
yt: 
fb: 
ig: 
tw: 
bio:
---

{{< profile/player/playerinfo name="Markocop" cleanname="markocop" bio="" >}} {{</ profile/player/playerinfo >}}